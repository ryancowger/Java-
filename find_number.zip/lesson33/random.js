self.addEventListener('message', function(msg) {
	var data = msg.data;
	var result = [];
	for (var i = 0; i < data; i++) {
		result.push(Math.random());
	}
	result.sort();
	self.postMessage(result[0]);
}, false);

function findLargest() {
        var max = 0;
        for (var i = 0; i <= 1000000000; i++) {
             max = Math.max(max, Math.random());
        }
        console.log(max);
   }

